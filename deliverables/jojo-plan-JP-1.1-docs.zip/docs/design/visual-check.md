# 对话设计稿显示检查

JP-1.1｜2026-09-25。检查对象screenboard.html是静态交互设计稿，所有数据为示例。

本地Playwright/Chromium完成40项检查：在1440×900和1100×900下逐个切换系统、护照、Skill、文档、PPT五种情境及执行/成果详情，检查新工作、能力库与设置；另外检查1100×720窗口。未出现文档级横向溢出或浏览器脚本错误。验证了子代理详情选择、Esc关闭、输入作为纯文本显示、规划PPT发送按钮禁用。

截图：[主对话](conversation-workspace.png)、[Agent与进程](agent-inspector.png)、[成果阅读](artifact-review.png)、[PPT扩展](ppt-extension.png)。主对话、Agent与PPT截图已逐张查看，文字、内容层级和主操作可读。旧14页设计稿不再作为当前界面依据。

未验证真实模型/进程、后台消息投递、完整焦点管理、200%缩放或安装。右侧覆盖面板的正式焦点约束需按T-48实现验收；静态稿展示结构不代表应用已开发。

本轮追加：常驻执行栏显示当前工作的智能体和后台Job数量，后台Job入口可打开sample-validator示例日志；已随原浏览器检查重新运行。截图见[后台Jobs](background-jobs.png)。
