# 交付物内容契约

JP-1.1。文件存在不代表内容齐全；阶段完成前同时检查结构、需求覆盖和证据。Markdown为正文规范，metadata保存结构化索引。

## 1. 内容模板

| kind | 必需内容 | 检查重点 |
| --- | --- | --- |
| research | 问题、范围、来源与时间、事实/推断/未知、替代方案、建议、验证计划 | 来源ID可解析；建议有证据或假设标记 |
| prd | 用户场景、范围/非目标、FR/AC、规则、非功能、风险、假设 | ID唯一、每FR有AC；关键未知不静默消失 |
| ux | 信息架构、流程、页面与状态/操作、组件、视觉稿、可访问性 | FR→UI映射；图像不是唯一规格 |
| briefing | 输入版本、角色理解、异议/回答、回写、负责人 | 架构/开发/测试均有理解摘要；阻断异议为0 |
| architecture | 架构图、模块、ER/数据字典、数据流、接口、状态、异常恢复、部署、ADR | 对应PRD/UX；接口和实体引用一致；不适用有理由 |
| test_design | 需求追踪、环境、数据标签、分层、用例预期、缺陷等级、门槛 | 每FR有测试；反例、故障、模拟/实测分开 |
| skill | SKILL.md、触发/不适用、输入输出、步骤、依赖、资源、样例 | 格式、路径、正反例、能力范围 |
| skill_group | 固定成员版本、DAG、输入映射、输出、整组样例 | 无环、无悬空、类型兼容、整体目标覆盖 |
| document | 读者、目的、大纲、正文、依据、限制、修订记录 | 实测有原始结果；引用定位；导出渲染 |
| rule | 依据/版本、条件、字段、判定、容差、例外、缺失处理、样例 | 来源存在、边界精度明确、领域复核 |
| dataset | 样本清单、来源/许可、标签、划分/排除、摘要、敏感级别 | hash、行数、评测/调优用途分开 |
| model_config | 服务/协议/型号、能力、参数、上下文/输出限制、版本 | 无密钥；检查匹配配置revision |
| prompt | 角色目标、输入输出合同、工具范围、未知处理、版本 | 无密钥；输出契约可校验 |
| code_snapshot | commit、工作树状态、包摘要、构建运行说明 | commit存在且对应测试目标；未提交变更明确 |
| test_evidence | case/run/operationId、目标版本、环境、实际结果、原始日志、模拟标记 | 实测由runner确认；pass/fail有依据 |
| review_report | reviewDimension、reviewerAttemptId、targetFingerprint、标准、结论、问题/证据/例外 | 维度齐全、目标一致、严重问题不被平均分掩盖 |
| release_manifest | 版本/hash、基线、环境、配置、迁移、预检、smoke、回滚、风险 | hash一致、无凭据、目标绑定 |

source、decision_log、operation_log使用系统记录格式；Agent生成正文不得冒充可信操作日志。

## 2. 综合审核团队

final-review启动三个独立会话，role可同为final_reviewer，但reviewDimension分别为product、technical、market_value。三个review_report缺一不可，不能用一段汇总代替三份审查。允许同一模型，不复用实现会话。

- product：对照PRD/UX和成果检查用户路径、范围与可用性。
- technical：核对架构、实现、测试、权限、恢复及发布条件。
- market_value：对照用户任务、替代方案和价值假设；没有真实数据说明证据不足，不伪造商业验证。

Service汇总问题，不用平均分决定通过。critical/major阻断；商业假设可由用户明确接受为试用风险，但不能变成“商业需求已证实”。三个报告指纹一致后提交用户决定。

## 3. 工程基线完整性

每FR必须关联UI（纯后台可说明不适用）、模块/接口、至少一项测试及研发任务；外部依赖有不可用处理；写操作有重试/恢复规则；生产路径有独立授权和核对方式。

结构校验只验证缺项、引用与ID；语义正确性仍需角色审阅、实验及用户/领域确认。JSON校验通过不等于PRD或审计规则正确。

## S1补充（2026-10-02）

prd、skill/skill_group和document的metadata.deliveryContract按[交付约定规范](16-delivery-contract.md)验证。正文与索引须一致，状态从可信记录推导；不新增可被模型直接写成通过的评分字段。
