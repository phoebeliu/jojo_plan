import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const MAX_BODY = 64 * 1024;

function json(res, status, value, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...headers });
  res.end(JSON.stringify(value));
}

async function parseBody(req) {
  const chunks = [];
  let bytes = 0;
  let oversized = false;
  for await (const chunk of req) {
    bytes += chunk.length;
    if (bytes > MAX_BODY) {
      oversized = true;
      chunks.length = 0;
    }
    if (!oversized) chunks.push(chunk);
  }
  if (oversized) throw Object.assign(new Error('请求体超过 64 KiB'), { status: 413 });
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw Object.assign(new Error('请求体必须是有效 JSON'), { status: 400 });
  }
}

export function createServer() {
  const todos = [];
  let nextId = 1;
  const server = http.createServer(async (req, res) => {
    try {
      const path = new URL(req.url, 'http://localhost').pathname;
      const methods = { '/': ['GET'], '/health': ['GET'], '/todos': ['GET', 'POST'] };
      if (!Object.hasOwn(methods, path)) return json(res, 404, { error: '路径不存在' });
      if (!methods[path].includes(req.method)) {
        return json(res, 405, { error: '不支持此方法' }, { Allow: methods[path].join(', ') });
      }
      if (path === '/') {
        const page = await readFile(new URL('./public/index.html', import.meta.url));
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        return res.end(page);
      }
      if (path === '/health') return json(res, 200, { status: 'ok' });
      if (req.method === 'GET') return json(res, 200, todos);
      const body = await parseBody(req);
      if (typeof body?.title !== 'string' || !body.title.trim()) {
        return json(res, 400, { error: '请输入非空字符串标题' });
      }
      const todo = { id: nextId++, title: body.title.trim() };
      todos.push(todo);
      return json(res, 201, todo);
    } catch (error) {
      if (!res.headersSent && !res.destroyed) {
        json(res, error.status || 500, { error: error.status ? error.message : '服务内部错误' });
      }
    }
  });
  server.requestTimeout = 10000;
  server.headersTimeout = 10000;
  return server;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT ?? 3000);
  if (!Number.isInteger(port) || port < 0 || port > 65535) {
    throw new Error('PORT 必须为 0 至 65535 的整数');
  }
  const server = createServer();
  server.on('error', error => {
    console.error(error.message);
    process.exitCode = 1;
  });
  server.listen(port, '127.0.0.1', () => {
    console.log(`待办服务：http://127.0.0.1:${server.address().port}/`);
  });
  for (const signal of ['SIGINT', 'SIGTERM']) {
    process.once(signal, () => {
      server.close();
      server.closeAllConnections();
    });
  }
}
