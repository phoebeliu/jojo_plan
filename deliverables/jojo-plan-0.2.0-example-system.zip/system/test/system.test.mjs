import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from '../server.mjs';

async function fixture(t) {
  const server = createServer();
  t.after(() => new Promise((resolve, reject) => {
    server.close(error => error ? reject(error) : resolve());
    server.closeAllConnections();
  }));
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  const base = `http://127.0.0.1:${server.address().port}`;
  return (path, options = {}) => fetch(base + path, {
    ...options,
    signal: AbortSignal.timeout(3000)
  });
}

const post = body => ({
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body)
});

async function list(request) {
  const response = await request('/todos');
  assert.equal(response.status, 200);
  return response.json();
}

test('健康检查返回 200 和 JSON', { timeout: 8000 }, async t => {
  const request = await fixture(t);
  const response = await request('/health');
  assert.equal(response.status, 200);
  assert.match(response.headers.get('content-type'), /application\/json/);
  assert.deepEqual(await response.json(), { status: 'ok' });
});

test('创建返回 201，trim 标题，唯一 ID，查询包含创建记录', { timeout: 8000 }, async t => {
  const request = await fixture(t);
  assert.deepEqual(await list(request), []);
  const created = [];
  for (const title of [' 合成待办A ', '合成待办B', '<b>合成</b>']) {
    const response = await request('/todos', post({ title }));
    assert.equal(response.status, 201);
    const todo = await response.json();
    assert.equal(todo.title, title.trim());
    assert.ok(Number.isInteger(todo.id) && todo.id > 0);
    created.push(todo);
  }
  assert.equal(new Set(created.map(todo => todo.id)).size, 3);
  assert.deepEqual(await list(request), created);
});

test('空串、空白、缺失及非字符串标题返回 400 且不改变列表', { timeout: 8000 }, async t => {
  const request = await fixture(t);
  const seed = await request('/todos', post({ title: '合成基线' }));
  assert.equal(seed.status, 201);
  await seed.json();
  const before = await list(request);
  for (const body of [{ title: '' }, { title: '   ' }, {}, { title: 123 }, { title: null }, null]) {
    const response = await request('/todos', post(body));
    assert.equal(response.status, 400);
    const error = (await response.json()).error;
    assert.equal(typeof error, 'string');
    assert.ok(error.length > 0);
    assert.deepEqual(await list(request), before);
  }
});

test('非法 JSON 和超限请求有错误响应且不写入', { timeout: 8000 }, async t => {
  const request = await fixture(t);
  for (const [body, status] of [
    ['{"title":', 400],
    [JSON.stringify({ title: 'A'.repeat(65536) }), 413]
  ]) {
    const response = await request('/todos', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body
    });
    assert.equal(response.status, status);
    assert.equal(typeof (await response.json()).error, 'string');
    assert.deepEqual(await list(request), []);
  }
});

test('未知路径 404，不支持的方法 405', { timeout: 8000 }, async t => {
  const request = await fixture(t);
  const missing = await request('/missing');
  assert.equal(missing.status, 404);
  assert.equal(typeof (await missing.json()).error, 'string');
  const unsupported = await request('/todos', { method: 'DELETE' });
  assert.equal(unsupported.status, 405);
  assert.equal(unsupported.headers.get('allow'), 'GET, POST');
  assert.equal(typeof (await unsupported.json()).error, 'string');
});

test('提供 HTML 页面，独立服务不共享内存数据', { timeout: 8000 }, async t => {
  const first = await fixture(t);
  const response = await first('/');
  assert.equal(response.status, 200);
  assert.match(response.headers.get('content-type'), /text\/html/);
  const html = await response.text();
  assert.match(html, /<form/);
  assert.match(html, /aria-live/);
  assert.match(html, /textContent/);
  const created = await first('/todos', post({ title: '合成隔离待办' }));
  assert.equal(created.status, 201);
  await created.json();
  const second = await fixture(t);
  assert.deepEqual(await list(second), []);
  assert.equal((await list(first)).length, 1);
});
