{
  "checks": [
    {
      "id": "format-title",
      "pass": true
    },
    {
      "id": "not-empty",
      "pass": true
    },
    {
      "id": "limitations",
      "pass": true
    }
  ],
  "container": null,
  "codeError": "",
  "criteria": [
    {
      "id": "AC-1",
      "statement": "健康检查200",
      "method": "both",
      "expected": "健康检查200",
      "required": true,
      "evidenceVersionIds": []
    },
    {
      "id": "AC-2",
      "statement": "创建201并能查询",
      "method": "both",
      "expected": "创建201并能查询",
      "required": true,
      "evidenceVersionIds": []
    },
    {
      "id": "AC-3",
      "statement": "空title400",
      "method": "both",
      "expected": "空title400",
      "required": true,
      "evidenceVersionIds": []
    },
    {
      "id": "AC-4",
      "statement": "包含页面、真实Node测试与启动说明",
      "method": "both",
      "expected": "包含页面、真实Node测试与启动说明",
      "required": true,
      "evidenceVersionIds": []
    }
  ],
  "status": "结构满足，语义待用户审阅"
}