{
  "checks": [
    {
      "id": "format-title",
      "pass": true
    },
    {
      "id": "not-empty",
      "pass": true
    },
    {
      "id": "limitations",
      "pass": true
    },
    {
      "id": "container-tests",
      "pass": false
    }
  ],
  "container": {
    "passed": false,
    "code": 143,
    "log": "",
    "image": "sha256:ebfe2f90462722a7a4de65e91990e97fe0d401c70e0e762c5b53302f905ec1c1"
  },
  "codeError": "",
  "criteria": [
    {
      "id": "AC-1",
      "statement": "健康检查200",
      "method": "both",
      "expected": "健康检查200",
      "required": true,
      "evidenceVersionIds": []
    },
    {
      "id": "AC-2",
      "statement": "创建201并能查询",
      "method": "both",
      "expected": "创建201并能查询",
      "required": true,
      "evidenceVersionIds": []
    },
    {
      "id": "AC-3",
      "statement": "空title400",
      "method": "both",
      "expected": "空title400",
      "required": true,
      "evidenceVersionIds": []
    },
    {
      "id": "AC-4",
      "statement": "包含页面、真实Node测试与启动说明",
      "method": "both",
      "expected": "包含页面、真实Node测试与启动说明",
      "required": true,
      "evidenceVersionIds": []
    }
  ],
  "status": "未通过"
}